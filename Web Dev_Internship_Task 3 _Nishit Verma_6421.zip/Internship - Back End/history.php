<?php
session_start();
if(isset($_SESSION['lastaction']))
{
    $inactive = time() - $_SESSION['lastaction'];
    $expire = 300;
    if($inactive > $expire)
    {
        session_unset();
        session_destroy();
        exit('<script>document.location="http://127.0.0.1/BackEnd/index.php"</script>');
    }
}
$_SESSION['lastaction'] = time();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Purchase History</title>
        <link rel="stylesheet" href="style.css">
	    <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            body{
                background-image: linear-gradient(to right,#000000,#5a5157,#000000);
            }
        </style>
    </head>
    <body>
        <div class="topnav" style="margin-left: 35%;">
            <a href="home.php">Home</a>&emsp;
            <a href="About2.php">About us</a>&emsp;
            <a href="home.php#Contact">Contact</a>&emsp;
            <a class="active" href="profile.php"><i style="font-size:24px" class="fa">&#xf2be;</i></a>
        </div>

        <div id="d2">
            <div class="topnav2" style="margin-left: 30%; max-width: 40%; float: left;">
                <a href="profile.php">Personal Info</a>&emsp;
                <a class="active" href="history.php">Purchase History</a>&emsp;
            </div>
            <a href="#" onclick="mod(); return false;" style="float: right;"><i style="font-size:48px; margin-top: 10%;" id="icon2" class="fa">&#xf08b;</i></a><br><br><br>
            <table id=tb>
                <tr><th>S.No</th><th>Course Name</th><th>Field</th><th>Price (INR)</th></tr>
                <?php
                if(isset($_SESSION['Userid']))
                {
                    $uid = $_SESSION['Userid'];
                    $servername = "localhost";
                    $username = "Nishit";
                    $password = "Webtech";
                    $dbname = "course_shop";
                    $conn = new mysqli($servername, $username, $password, $dbname);
                                
                    $sql = "SELECT Userid, Sub, Field, Price FROM History WHERE Userid = '$uid'";
                    $result=$conn->query($sql);
                    $i = 1;
                    $uid = $sub = $field = $price = "";
                    if($result->num_rows>0) 
                    {
                        While($row =$result->fetch_assoc()) 
                        {
                            $uid = $row['Userid'];
                            $sub = $row["Sub"];
                            $field = $row['Field'];
                            $price = $row['Price'];

                            echo "<tr><td>".$i."</td><td>".$sub."</td><td>".$field."</td><td>".$price."</td></tr>";
                            $i++;
                        }
                    }
                    $conn->close();
                }
                ?>
            </table>
        </div><br><br>

        <div id="myModal" class="modal">

            <div class="modal-content">
                <div class="modal-header" style="background-color: white; color: black;">
                    <span class="close" style="color: black; margin-top: 7%;">&times;</span>
                    <h2 style="margin-top: 7%; margin-left: 5%;">Are you sure you want to Log Out ?</h2>
                </div>
                <div class="modal-body">
                <form method="post">
                    <button id="btn1" name="btn1" value="Yes">Yes</button>
                    <button id="btn2" name="btn2" value="No">No</button>
                </form>
                </div>
            </div>
        </div>
        <?php
        if(array_key_exists('btn1', $_POST)) 
        {
            session_unset();
            session_destroy();
            exit('<script>document.location="http://127.0.0.1/BackEnd/index.php"</script>');
        }
        ?>
        <script>
            var modal = document.getElementById("myModal");
            var span = document.getElementsByClassName("close")[0];

            function mod() {
              modal.style.display = "block";
            }
            
            span.onclick = function() {
              modal.style.display = "none";
            }

            window.onclick = function(event) {
              if (event.target == modal) {
                modal.style.display = "none";
              }
            }
        </script>
    </body>
</html>
<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    
  if ($_SERVER["REQUEST_METHOD"] == "POST") 
  {
    $servername = "localhost";
    $username = "Nishit";
    $password = "Webtech";
    $dbname = "course_shop";
    $conn = new mysqli($servername, $username, $password, $dbname);
    $uid = $_POST['uname'];
                
    $sql = "SELECT Name, Userid, Email, Password FROM course_shop_app WHERE Userid = '$uid'";
    $result=$conn->query($sql);

    $name = $uid = $em = $ps = $to = $subject = $message = $header = "";
    if($result->num_rows>0) 
    {
	    While($row =$result->fetch_assoc()) 
      {
            $name = $row["Name"];
            $uid = $row["Userid"];
            $em = $row["Email"];
            $ps = $row["Password"];
	    }

      require 'PHPMailer-master/src/Exception.php';
      require 'PHPMailer-master/src/PHPMailer.php';
      require 'PHPMailer-master/src/SMTP.php';

      require_once "vendor/autoload.php";
    
      $mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'nishitverma1312@gmail.com';                     //SMTP username
    $mail->Password   = 'sheru3479';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('nishitverma1312@gmail.com', 'Nishit Verma');
    $mail->addAddress($em, $name);     //Add a recipient
    //$mail->addAddress($em);               //Name is optional
    $mail->addReplyTo('nishitverma1312@gmail.com', 'Nishit Verma');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Your Password';
    $mail->Body    = 'Hello '.$name.',<br>The password for the User Id : <b>'.$uid.'</b> is "<b>'.$ps.'</b>".';
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    exit('<script>alert("Password has been sent to your mail");document.location="http://127.0.0.1/BackEnd/index.php"</script>');
    } 
    catch (Exception $e) 
    {
      exit('<script>alert("Due to some errors, mail could not be sent..!! Please Try Again Later");document.location="http://127.0.0.1/BackEnd/fp.php"</script>');
    }
    }
    else
    {
      exit('<script>alert("Invalid User ID..!!");document.location="http://127.0.0.1/BackEnd/fp.php"</script>');
    }
    $conn->close();
  }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Course Shop App - Retrieve Password</title>
        <link rel="stylesheet" href="style.css">
	    <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
        <style>
          #d{
            margin-top: 9%;
          }
        </style>
    </head>
    <body>
        <div class="topnav" id="topnav">
            <a class="active" href="index.php">Home</a>&emsp;
            <a href="About.php">About us</a>&emsp;
            <a href="#Contact">Contact</a>&emsp;
        </div>
        <div id="d">
          <p id="p1">Welcome To</p>
          <h1 class="ml15">
            <span class="text-wrapper">
              <span class="letters" style="color: white;">Course Shop App</span>
              <span class="line"></span>
            </span>
          </h1><br>
          <p id="p2">Explore a whole new world of learning..!!</p>
        </div>
    <div id="d1" style="margin-top: 10%;">
    <form method="POST" enctype="multipart/form-data">
        <H1 id="head1">Retrieve Password</H1>
        <input type="text" id="uname" name="uname" placeholder="User Name" required><br><br>
        <input type="submit" id="bt1" name="bt1" class="bt1" value="Submit"/>
        <p id = pr style="text-align : center"><a href="index.php" style="text-decoration: none; color: red;">Sign in</a> / <a href="signup.php" style="text-decoration: none;  color: red;">Register Now</a></p> 
    </form>
</div><br><br><br><br><br>
<div id="Contact">
    <h1 class="ml14">
      <span class="text-wrapper">
        <span class="letters" style="color: white;">Course Shop App</span>
        <span class="line"></span>
      </span>
    </h1><br>
    <script>
      var textWrapper = document.querySelector('.ml14 .letters');
      textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

      anime.timeline({loop: true})
      .add({
        targets: '.ml14 .line',
        scaleX: [0,1],
        opacity: [0.5,1],
        easing: "easeInOutExpo",
        duration: 900
      }).add({
        targets: '.ml14 .letter',
        opacity: [0,1],
        translateX: [40,0],
        translateZ: 0,
        scaleX: [0.3, 1],
        easing: "easeOutExpo",
        duration: 800,
        offset: '-=600',
      delay: (el, i) => 150 + 25 * i
      }).add({
        targets: '.ml14',
        opacity: 0,
        duration: 1000,
        easing: "easeOutExpo",
        delay: 1000
      });
    </script>
    <a href="https://www.facebook.com/education4ol4" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true" style="color: white; font-size: 50px;"></i></a>&emsp;
    <a href="https://www.linkedin.com/company/education-4-ol/" target="_blank"><i class="fa fa-linkedin-square" aria-hidden="true" style="color: white; font-size: 50px;"></i></a>&emsp;
    <a href="https://www.instagram.com/education_4_ol/" target="_blank"><i class="fa fa-instagram" aria-hidden="true" style="color: white; font-size: 50px;"></i></a>&emsp;<br>
    <p>Educa</p>
  </div>
</body>
</html>

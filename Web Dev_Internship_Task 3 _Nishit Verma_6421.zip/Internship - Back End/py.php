<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        if(array_key_exists('bt3', $_POST)) 
        {
            if(isset($_SESSION['Userid']))
            {
                $uid = $sub = $field = $price = "";
                $uid = $_SESSION['Userid'];
                $sub = $_SESSION["sub"];
                $field = $_SESSION['fld'];
                $price = $_SESSION['pr'];
                $servername = "localhost";
                $username = "Nishit";
                $password = "Webtech";
                $dbname = "course_shop";
                $conn = new mysqli($servername, $username, $password, $dbname);
                $sql = "INSERT INTO history (Userid, Sub, Field, Price) VALUES ('$uid', '$sub', '$field', '$price')";
                if ($conn->query($sql) === TRUE) 
                {
                    exit('<script>alert("Transaction Successful");document.location="http://127.0.0.1/BackEnd/home.php"</script>');
                }
                else
                {
                    exit('<script>alert("Transaction Failed..!! Please Try Again Later");document.location="http://127.0.0.1/BackEnd/payment.php"</script>');
                }
                $conn->close();
            }
        }
        if(array_key_exists('bt4', $_POST)) 
        {
            exit('<script>document.location="http://127.0.0.1/BackEnd/home.php"</script>');
        }
    }
?>

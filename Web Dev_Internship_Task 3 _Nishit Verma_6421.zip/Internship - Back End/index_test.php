<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
                $uid = $_POST['uname'];
                $servername = "localhost";
                $username = "Nishit";
                $password = "Webtech";
                $dbname = "course_shop";
                $conn = new mysqli($servername, $username, $password, $dbname);
                
                $sql = "SELECT Userid, Password FROM course_shop_app WHERE Userid = '$uid'";
                $result=$conn->query($sql);

                $user = $ps = "";
                if($result->num_rows>0) 
                {
	                While($row =$result->fetch_assoc()) 
                    {
                        $user = $row["Userid"];
                        $ps = $row["Password"];
	                }
                }
                if ($_SERVER["REQUEST_METHOD"] == "POST") 
                {
                    $pass = $_POST['pass'];
                    if($uid == $user && $pass == $ps)
                    {
                        session_start();
                        $_SESSION['Userid'] = $uid;
                        header("Location: home.php");
                    }
                    else
                    {
                        exit('<script>alert("Invalid User Id or Password..!!");document.location="http://127.0.0.1/BackEnd/index.php"</script>');
                    }
                }
                $conn->close();
    }
?>
